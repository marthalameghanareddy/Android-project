package com.example.conveyapp3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.widget.EditText;
import java.util.Locale;
import android.view.View;

public class TextToSpeechPage extends AppCompatActivity {
    private EditText ed1;
    private TextToSpeech textToSpeech;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_to_speech_page);
        ed1=(EditText)findViewById(R.id.editTextId);
        textToSpeech = new TextToSpeech(getApplicationContext(),new TextToSpeech.OnInitListener(){
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    textToSpeech.setLanguage(Locale.UK);
                }
            }
        });
    }
    public void clickToListen(View view){
        textToSpeech.speak(ed1.getText().toString(), TextToSpeech.QUEUE_FLUSH,  null, null);
    }
}
